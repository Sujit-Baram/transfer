self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a8bae0ea432b1a71d5333c8766986a52",
    "url": "/index.html"
  },
  {
    "revision": "95dd8ca56c0be2d55dcb",
    "url": "/static/css/1.f2861d0b.chunk.css"
  },
  {
    "revision": "00053639473f575af4cf",
    "url": "/static/css/13.de24c338.chunk.css"
  },
  {
    "revision": "910b983e05ddb230d3f5",
    "url": "/static/css/14.0cf29192.chunk.css"
  },
  {
    "revision": "c30ad5addb3f0803f666",
    "url": "/static/css/15.8e82e50d.chunk.css"
  },
  {
    "revision": "365c49401f23422eed3d",
    "url": "/static/css/20.ee74ad4f.chunk.css"
  },
  {
    "revision": "2c008c42f777ffd5b5ff",
    "url": "/static/css/37.ee74ad4f.chunk.css"
  },
  {
    "revision": "240759fd7cb96516d0c8",
    "url": "/static/css/38.ee74ad4f.chunk.css"
  },
  {
    "revision": "ac0ef276e7d4a5c56215",
    "url": "/static/css/6.8e82e50d.chunk.css"
  },
  {
    "revision": "97f67ec5c729be3c6da2",
    "url": "/static/css/main.674da818.chunk.css"
  },
  {
    "revision": "700d51ed76f1902f43c5",
    "url": "/static/js/0.bf1bb12d.chunk.js"
  },
  {
    "revision": "455f9f3ae849b1b7c9d5b5f2d351830a",
    "url": "/static/js/0.bf1bb12d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "95dd8ca56c0be2d55dcb",
    "url": "/static/js/1.4ff4d118.chunk.js"
  },
  {
    "revision": "c1b265d5aef810b97844",
    "url": "/static/js/10.2940e5ba.chunk.js"
  },
  {
    "revision": "00053639473f575af4cf",
    "url": "/static/js/13.2f4a23a5.chunk.js"
  },
  {
    "revision": "50356a9d5090f44699126fc40c655fc4",
    "url": "/static/js/13.2f4a23a5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "910b983e05ddb230d3f5",
    "url": "/static/js/14.07b53294.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/14.07b53294.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c30ad5addb3f0803f666",
    "url": "/static/js/15.d401619f.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/15.d401619f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "718e6eec5c2c2489f520",
    "url": "/static/js/16.7e104de5.chunk.js"
  },
  {
    "revision": "152ea931974511656c226599e75b3f3d",
    "url": "/static/js/16.7e104de5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d39e70e853cf2cdd43b3",
    "url": "/static/js/17.ae14f8b4.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/17.ae14f8b4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "50056fd0e36250353cc0",
    "url": "/static/js/18.eb53d7ed.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/18.eb53d7ed.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7e1c2d4f97cb18af92b5",
    "url": "/static/js/19.f321f81d.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/19.f321f81d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ada3b9a54f45427f80fe",
    "url": "/static/js/2.f63c6fa5.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/2.f63c6fa5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "365c49401f23422eed3d",
    "url": "/static/js/20.f2f2ffb1.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/20.f2f2ffb1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "dfe569db5a7c05193f3e",
    "url": "/static/js/21.d5ad0371.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/21.d5ad0371.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d47d4032d5a986b7a6da",
    "url": "/static/js/22.0286c002.chunk.js"
  },
  {
    "revision": "50356a9d5090f44699126fc40c655fc4",
    "url": "/static/js/22.0286c002.chunk.js.LICENSE.txt"
  },
  {
    "revision": "55081274cb8df9e403e6",
    "url": "/static/js/23.675e4d18.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/23.675e4d18.chunk.js.LICENSE.txt"
  },
  {
    "revision": "964c5ebc9f7aa5e28cbd",
    "url": "/static/js/24.06d3b94a.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/24.06d3b94a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "db0e58fea7d0b18ed0c7",
    "url": "/static/js/25.7516cea7.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/25.7516cea7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0d9c987c7ae9a82e7fb2",
    "url": "/static/js/26.ec9189f5.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/26.ec9189f5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3ad502d5ad687081a565",
    "url": "/static/js/27.8209a205.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/27.8209a205.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4f274672f4f4cb21f93d",
    "url": "/static/js/28.4d2607d8.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/28.4d2607d8.chunk.js.LICENSE.txt"
  },
  {
    "revision": "363094fa777ab9b51f4b",
    "url": "/static/js/29.22352816.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/29.22352816.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ffb1be8877ff2b48ae83",
    "url": "/static/js/3.fdea2a26.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "/static/js/3.fdea2a26.chunk.js.LICENSE.txt"
  },
  {
    "revision": "040fb5eaadc0f31b0a3a",
    "url": "/static/js/30.81411608.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/30.81411608.chunk.js.LICENSE.txt"
  },
  {
    "revision": "62fbe06c0e327f4148a1",
    "url": "/static/js/31.535292f0.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/31.535292f0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f2d29f651428a9c59dbe",
    "url": "/static/js/32.0828c4f9.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/32.0828c4f9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e2218ce3e9304a72e3cf",
    "url": "/static/js/33.bed23ef5.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/33.bed23ef5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6f41aea8008d38e411ad",
    "url": "/static/js/34.be5338aa.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/34.be5338aa.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3c7a48eac605e3570f83",
    "url": "/static/js/35.95f32f9a.chunk.js"
  },
  {
    "revision": "50356a9d5090f44699126fc40c655fc4",
    "url": "/static/js/35.95f32f9a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "66f1675d318fc750de9c",
    "url": "/static/js/36.ae40f914.chunk.js"
  },
  {
    "revision": "9014f75bee2b03e13e1876e3edc1005c",
    "url": "/static/js/36.ae40f914.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2c008c42f777ffd5b5ff",
    "url": "/static/js/37.8301c2f6.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/37.8301c2f6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "240759fd7cb96516d0c8",
    "url": "/static/js/38.7c553873.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/38.7c553873.chunk.js.LICENSE.txt"
  },
  {
    "revision": "de6c2e03e6317fcf6616",
    "url": "/static/js/39.c5079e72.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/39.c5079e72.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b23670a608bf82589f2c",
    "url": "/static/js/4.fe1f2274.chunk.js"
  },
  {
    "revision": "91d6442ff67a1d5729e0",
    "url": "/static/js/40.22cb6e57.chunk.js"
  },
  {
    "revision": "1bd5c751d53b71c0ea7981675300a350",
    "url": "/static/js/40.22cb6e57.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6d5e76262e63f45a978b",
    "url": "/static/js/41.5dfd596b.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/41.5dfd596b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2fde0a8de9b132a208a1",
    "url": "/static/js/42.1d1892c3.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/42.1d1892c3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "024e1c8422b32f26e31b",
    "url": "/static/js/43.97f640e2.chunk.js"
  },
  {
    "revision": "7c39f43073ef06004af2",
    "url": "/static/js/44.d1685175.chunk.js"
  },
  {
    "revision": "9e6dbcb85c5b270b6786",
    "url": "/static/js/45.0861417f.chunk.js"
  },
  {
    "revision": "1c4f57555f69c2fb4e80",
    "url": "/static/js/46.6ecfd420.chunk.js"
  },
  {
    "revision": "3613977c375a61986b2a",
    "url": "/static/js/47.dc6a2846.chunk.js"
  },
  {
    "revision": "59741aa3fc8390a2ff11",
    "url": "/static/js/48.9b564fbe.chunk.js"
  },
  {
    "revision": "90b35271b4830517097c",
    "url": "/static/js/49.750c5c52.chunk.js"
  },
  {
    "revision": "e28ba4139c021752bcb2",
    "url": "/static/js/5.aac6770c.chunk.js"
  },
  {
    "revision": "9496526879df9f1f8809",
    "url": "/static/js/50.6de71ba5.chunk.js"
  },
  {
    "revision": "a3cb347719a0375f4e28",
    "url": "/static/js/51.eb20d338.chunk.js"
  },
  {
    "revision": "98836969a9bbc03414b4",
    "url": "/static/js/52.8f31d902.chunk.js"
  },
  {
    "revision": "5150276a922414f52fae",
    "url": "/static/js/53.546230d2.chunk.js"
  },
  {
    "revision": "a00f46dbc834325f9c05",
    "url": "/static/js/54.df959936.chunk.js"
  },
  {
    "revision": "a9c40c55dcbf1ed9f9f2",
    "url": "/static/js/55.b0096c81.chunk.js"
  },
  {
    "revision": "0472603793ef7417ebc5",
    "url": "/static/js/56.89be5542.chunk.js"
  },
  {
    "revision": "c4f4fc6d3fa6a48b2138",
    "url": "/static/js/57.22154bd2.chunk.js"
  },
  {
    "revision": "099bf136a786cb57793e",
    "url": "/static/js/58.475c502e.chunk.js"
  },
  {
    "revision": "ac0ef276e7d4a5c56215",
    "url": "/static/js/6.b8d03518.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/6.b8d03518.chunk.js.LICENSE.txt"
  },
  {
    "revision": "706b552e1904ba6a7408",
    "url": "/static/js/7.ddae1aea.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/static/js/7.ddae1aea.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f0c7c99d100317924107",
    "url": "/static/js/8.e5989b2f.chunk.js"
  },
  {
    "revision": "85819f57a4f2c708e1ba",
    "url": "/static/js/9.da2f282f.chunk.js"
  },
  {
    "revision": "97f67ec5c729be3c6da2",
    "url": "/static/js/main.61e668bb.chunk.js"
  },
  {
    "revision": "d044bd8d5f5ed19178c6",
    "url": "/static/js/runtime-main.f57b3251.js"
  },
  {
    "revision": "f1c39bddd98308d592280a043ae373e6",
    "url": "/static/media/FAC-LOGO.f1c39bdd.png"
  },
  {
    "revision": "45bc9a197a82b2184132d9302571a1f1",
    "url": "/static/media/admin.45bc9a19.png"
  },
  {
    "revision": "b9c73089fd14dcb97bf597665f575ac1",
    "url": "/static/media/bell.b9c73089.svg"
  },
  {
    "revision": "0668938486df8e4ded8fd7bb86c72452",
    "url": "/static/media/block.06689384.svg"
  },
  {
    "revision": "24886bacc88f3dfbf038a60f4f9f0921",
    "url": "/static/media/bot.24886bac.svg"
  },
  {
    "revision": "ae6d8356288db42a438a49fc4bd53b4e",
    "url": "/static/media/buttons.ae6d8356.svg"
  },
  {
    "revision": "54c5d4c68ff0df625eea98a10b16f6f7",
    "url": "/static/media/cards.54c5d4c6.svg"
  },
  {
    "revision": "977becb6db37f454bad0a5b18f6e647a",
    "url": "/static/media/cart.977becb6.svg"
  },
  {
    "revision": "057753b09a212e5160fe854595ffe79f",
    "url": "/static/media/charts.057753b0.svg"
  },
  {
    "revision": "f7fdff0357cd6bbf4d41ff8aac44a033",
    "url": "/static/media/chat.f7fdff03.svg"
  },
  {
    "revision": "80c792931a140e6917fa643593bca0c5",
    "url": "/static/media/coin.80c79293.svg"
  },
  {
    "revision": "f08813da08c47f23122a2827c74b2fb2",
    "url": "/static/media/coupon.f08813da.svg"
  },
  {
    "revision": "d34c7b50751314310124af5f5b5fbcf3",
    "url": "/static/media/create-account-office-dark.d34c7b50.jpeg"
  },
  {
    "revision": "41b2c6a1c926a8d4f86152f315c7a0bb",
    "url": "/static/media/create-account-office.41b2c6a1.jpeg"
  },
  {
    "revision": "669401e2e4096f9c206e1813f94f2bd0",
    "url": "/static/media/delete.669401e2.svg"
  },
  {
    "revision": "c34040acd2b1249c7cd75ce72a0a36f6",
    "url": "/static/media/dropdown.c34040ac.svg"
  },
  {
    "revision": "c95d727ec5861e3bd1c40034aec6c2ff",
    "url": "/static/media/earning.c95d727e.svg"
  },
  {
    "revision": "41c3abf6450e891dd3dd0c725187eb92",
    "url": "/static/media/edit.41c3abf6.svg"
  },
  {
    "revision": "e8dbb81080cd5c72c595ae891f61fc0b",
    "url": "/static/media/favicon.e8dbb810.png"
  },
  {
    "revision": "df8aaef727cafdb462dc6a3ef66021d6",
    "url": "/static/media/forbidden.df8aaef7.svg"
  },
  {
    "revision": "6db046dc83427f6c5152a760ec3c9d98",
    "url": "/static/media/forgot-password-office-dark.6db046dc.jpeg"
  },
  {
    "revision": "ac5c499bcee89dd25a8b8c80ed46fb8e",
    "url": "/static/media/forgot-password-office.ac5c499b.jpeg"
  },
  {
    "revision": "2da2d1896888bd5229d978ee2298b072",
    "url": "/static/media/forms.2da2d189.svg"
  },
  {
    "revision": "14c57205ad4f4e99cd8b45547800a3e8",
    "url": "/static/media/game.14c57205.svg"
  },
  {
    "revision": "77016819da953ea8a4a60950acb99b99",
    "url": "/static/media/github.77016819.svg"
  },
  {
    "revision": "0d8cfa09614809887b157eba25082af1",
    "url": "/static/media/heart.0d8cfa09.svg"
  },
  {
    "revision": "9bce792512f4e921fa481dcc272660a5",
    "url": "/static/media/home.9bce7925.svg"
  },
  {
    "revision": "5d5cd2055b2ae7f03053b5e243f01620",
    "url": "/static/media/icon.5d5cd205.png"
  },
  {
    "revision": "a824586f0a38494843dc7b98d84ccd47",
    "url": "/static/media/league.a824586f.svg"
  },
  {
    "revision": "cb4a995ff675060363e7489041041b85",
    "url": "/static/media/login-office-dark.cb4a995f.jpeg"
  },
  {
    "revision": "e8edbe5b89f1a31eb88a2ff2d3cb34eb",
    "url": "/static/media/mail.e8edbe5b.svg"
  },
  {
    "revision": "df9ba7c81d8c805ebf3d84a48bd9d57c",
    "url": "/static/media/menu.df9ba7c8.svg"
  },
  {
    "revision": "62a5a8fff7ff6bef7bf961f2a889dc21",
    "url": "/static/media/modals.62a5a8ff.svg"
  },
  {
    "revision": "235b238e2d98c19986f60c19ec2fdb0e",
    "url": "/static/media/money.235b238e.svg"
  },
  {
    "revision": "cdf19a70cc4aad218e3b50d3ee1f6866",
    "url": "/static/media/moon.cdf19a70.svg"
  },
  {
    "revision": "a9704b46814fc81873ac98ca917aa5c4",
    "url": "/static/media/notification.a9704b46.svg"
  },
  {
    "revision": "570b0d66f31d545fdbdc30f5eefaa126",
    "url": "/static/media/outlineCog.570b0d66.svg"
  },
  {
    "revision": "011a8da20be3a5ddd88f392574549839",
    "url": "/static/media/outlineLogout.011a8da2.svg"
  },
  {
    "revision": "50f0ae3e598fe90d94336b5492c772c1",
    "url": "/static/media/outlinePerson.50f0ae3e.svg"
  },
  {
    "revision": "6650d5109fafc0724eac274c3b43eed5",
    "url": "/static/media/pages.6650d510.svg"
  },
  {
    "revision": "c4fada77c844618fef90d2194039d452",
    "url": "/static/media/people.c4fada77.svg"
  },
  {
    "revision": "70205477154d7db80b2f05e9716eb3c1",
    "url": "/static/media/search.70205477.svg"
  },
  {
    "revision": "71c83b534f68121c2e24011e464623cd",
    "url": "/static/media/settings.71c83b53.svg"
  },
  {
    "revision": "e72f14b8a27c721f10d5eb87e8ec3d2f",
    "url": "/static/media/sun.e72f14b8.svg"
  },
  {
    "revision": "b9ce44e708d154ec60a8deabeb3e8e58",
    "url": "/static/media/tables.b9ce44e7.svg"
  },
  {
    "revision": "363c49e4f74fa93affa964689967406a",
    "url": "/static/media/tournament.363c49e4.svg"
  },
  {
    "revision": "f3c7c3b232acfe1a6250f640a0a17741",
    "url": "/static/media/trash.f3c7c3b2.svg"
  },
  {
    "revision": "758d4ea92606195e7b3245047e7f8c4c",
    "url": "/static/media/trophy.758d4ea9.png"
  },
  {
    "revision": "c6bd77d7d4321627a185c1cbc89276d8",
    "url": "/static/media/twitter.c6bd77d7.svg"
  },
  {
    "revision": "50d7bcea8b900a0d51c407df18b726ee",
    "url": "/static/media/user.50d7bcea.svg"
  },
  {
    "revision": "4d17d984fe601c2810b35f1ac207a30c",
    "url": "/static/media/view.4d17d984.svg"
  },
  {
    "revision": "7f5a55ecf21dd1d848585c4db79c8818",
    "url": "/static/media/voucher.7f5a55ec.svg"
  },
  {
    "revision": "1113e51cd421885a70455575e87db7e2",
    "url": "/static/media/word.1113e51c.svg"
  }
]);
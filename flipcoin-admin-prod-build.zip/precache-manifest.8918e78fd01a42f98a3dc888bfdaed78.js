self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ef2dfab0eb56c9879a8cd22ef4370fea",
    "url": "/flipacoin-admin/index.html"
  },
  {
    "revision": "a082abf38136d23f6177",
    "url": "/flipacoin-admin/static/css/1.f2861d0b.chunk.css"
  },
  {
    "revision": "27ffd7d5078c611f7377",
    "url": "/flipacoin-admin/static/css/13.de24c338.chunk.css"
  },
  {
    "revision": "32c7a17675e6f662e6e8",
    "url": "/flipacoin-admin/static/css/14.0cf29192.chunk.css"
  },
  {
    "revision": "ea91e1988ce576e6651e",
    "url": "/flipacoin-admin/static/css/15.8e82e50d.chunk.css"
  },
  {
    "revision": "6539608443cde980f50f",
    "url": "/flipacoin-admin/static/css/20.ee74ad4f.chunk.css"
  },
  {
    "revision": "3e79199a2d153046a49d",
    "url": "/flipacoin-admin/static/css/22.dca4006b.chunk.css"
  },
  {
    "revision": "329e7a9d4d6999d9b2cb",
    "url": "/flipacoin-admin/static/css/32.de24c338.chunk.css"
  },
  {
    "revision": "315a460f5e56bc253b91",
    "url": "/flipacoin-admin/static/css/41.ee74ad4f.chunk.css"
  },
  {
    "revision": "f9c4ecd2b28a7ce5805b",
    "url": "/flipacoin-admin/static/css/42.ee74ad4f.chunk.css"
  },
  {
    "revision": "9eee1b00ef240f84e8f1",
    "url": "/flipacoin-admin/static/css/6.8e82e50d.chunk.css"
  },
  {
    "revision": "d967ce52107f38c6969f",
    "url": "/flipacoin-admin/static/css/main.674da818.chunk.css"
  },
  {
    "revision": "904eafead475edbce903",
    "url": "/flipacoin-admin/static/js/0.06959c80.chunk.js"
  },
  {
    "revision": "455f9f3ae849b1b7c9d5b5f2d351830a",
    "url": "/flipacoin-admin/static/js/0.06959c80.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a082abf38136d23f6177",
    "url": "/flipacoin-admin/static/js/1.0308308d.chunk.js"
  },
  {
    "revision": "087fff589e06099e2b9d",
    "url": "/flipacoin-admin/static/js/10.a371c9ea.chunk.js"
  },
  {
    "revision": "27ffd7d5078c611f7377",
    "url": "/flipacoin-admin/static/js/13.fa866a3e.chunk.js"
  },
  {
    "revision": "50356a9d5090f44699126fc40c655fc4",
    "url": "/flipacoin-admin/static/js/13.fa866a3e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "32c7a17675e6f662e6e8",
    "url": "/flipacoin-admin/static/js/14.6908f975.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/14.6908f975.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ea91e1988ce576e6651e",
    "url": "/flipacoin-admin/static/js/15.92bbb283.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/15.92bbb283.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a167488aaf5dc47cb73d",
    "url": "/flipacoin-admin/static/js/16.2c5690a6.chunk.js"
  },
  {
    "revision": "152ea931974511656c226599e75b3f3d",
    "url": "/flipacoin-admin/static/js/16.2c5690a6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c927c67010923a7d2458",
    "url": "/flipacoin-admin/static/js/17.cb4b84de.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/17.cb4b84de.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7c0bb68c3091fcfd33e8",
    "url": "/flipacoin-admin/static/js/18.14e9bae9.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/18.14e9bae9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ec6c8d3b2ec8f82fb780",
    "url": "/flipacoin-admin/static/js/19.155b1007.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/19.155b1007.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f6ca3a7e682ee24075c8",
    "url": "/flipacoin-admin/static/js/2.03f880eb.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/2.03f880eb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6539608443cde980f50f",
    "url": "/flipacoin-admin/static/js/20.e50ab3c0.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/20.e50ab3c0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ea52f43d35164b48ebff",
    "url": "/flipacoin-admin/static/js/21.4e7a1013.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/21.4e7a1013.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3e79199a2d153046a49d",
    "url": "/flipacoin-admin/static/js/22.d235ca04.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/22.d235ca04.chunk.js.LICENSE.txt"
  },
  {
    "revision": "021c39886f8e8246645e",
    "url": "/flipacoin-admin/static/js/23.3531ba7b.chunk.js"
  },
  {
    "revision": "50356a9d5090f44699126fc40c655fc4",
    "url": "/flipacoin-admin/static/js/23.3531ba7b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "644b533ee32290d0d5cb",
    "url": "/flipacoin-admin/static/js/24.ca01a658.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/24.ca01a658.chunk.js.LICENSE.txt"
  },
  {
    "revision": "231e496cde7929f03f21",
    "url": "/flipacoin-admin/static/js/25.a58f1007.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/25.a58f1007.chunk.js.LICENSE.txt"
  },
  {
    "revision": "de5bfa6882679545843d",
    "url": "/flipacoin-admin/static/js/26.88eb2605.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/26.88eb2605.chunk.js.LICENSE.txt"
  },
  {
    "revision": "94d1b45ce62c84a33ed0",
    "url": "/flipacoin-admin/static/js/27.9330fb44.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/27.9330fb44.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0b159e0c661576628843",
    "url": "/flipacoin-admin/static/js/28.f1a4d6d5.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/28.f1a4d6d5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8de6e612148de82a9cc4",
    "url": "/flipacoin-admin/static/js/29.b6bd7043.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/29.b6bd7043.chunk.js.LICENSE.txt"
  },
  {
    "revision": "88be182127e7740f328b",
    "url": "/flipacoin-admin/static/js/3.bcc203f2.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "/flipacoin-admin/static/js/3.bcc203f2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e9b4fa80d3f3b8cb7725",
    "url": "/flipacoin-admin/static/js/30.d28a8a8c.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/30.d28a8a8c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9e710b9c6e02d7a989f5",
    "url": "/flipacoin-admin/static/js/31.c2bea9b7.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/31.c2bea9b7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "329e7a9d4d6999d9b2cb",
    "url": "/flipacoin-admin/static/js/32.c9332440.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/32.c9332440.chunk.js.LICENSE.txt"
  },
  {
    "revision": "85f431555b7064fe00f9",
    "url": "/flipacoin-admin/static/js/33.0fab1ce1.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/33.0fab1ce1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "59959f744e3d379ffa6f",
    "url": "/flipacoin-admin/static/js/34.b59a2d04.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/34.b59a2d04.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c99fa6b1de8311c4249e",
    "url": "/flipacoin-admin/static/js/35.e358d41e.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/35.e358d41e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "43c6eceae139bd653897",
    "url": "/flipacoin-admin/static/js/36.50be779b.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/36.50be779b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b419189366182a708d76",
    "url": "/flipacoin-admin/static/js/37.3198a505.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/37.3198a505.chunk.js.LICENSE.txt"
  },
  {
    "revision": "077acf82fb17bebd7b8c",
    "url": "/flipacoin-admin/static/js/38.0825eb51.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/38.0825eb51.chunk.js.LICENSE.txt"
  },
  {
    "revision": "950ea8a4df79a0953adb",
    "url": "/flipacoin-admin/static/js/39.ef846e61.chunk.js"
  },
  {
    "revision": "50356a9d5090f44699126fc40c655fc4",
    "url": "/flipacoin-admin/static/js/39.ef846e61.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7f70e7ce4875f2e95c17",
    "url": "/flipacoin-admin/static/js/4.ffe3c2cd.chunk.js"
  },
  {
    "revision": "df595da4656e6bd283b4",
    "url": "/flipacoin-admin/static/js/40.856e5044.chunk.js"
  },
  {
    "revision": "9014f75bee2b03e13e1876e3edc1005c",
    "url": "/flipacoin-admin/static/js/40.856e5044.chunk.js.LICENSE.txt"
  },
  {
    "revision": "315a460f5e56bc253b91",
    "url": "/flipacoin-admin/static/js/41.1f2199d2.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/41.1f2199d2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f9c4ecd2b28a7ce5805b",
    "url": "/flipacoin-admin/static/js/42.c12795d4.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/42.c12795d4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d350e34a02576d629316",
    "url": "/flipacoin-admin/static/js/43.95ac7e15.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/43.95ac7e15.chunk.js.LICENSE.txt"
  },
  {
    "revision": "002837136c5b1cde5db2",
    "url": "/flipacoin-admin/static/js/44.4a4c297f.chunk.js"
  },
  {
    "revision": "1bd5c751d53b71c0ea7981675300a350",
    "url": "/flipacoin-admin/static/js/44.4a4c297f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8f75cc294638a535b5d0",
    "url": "/flipacoin-admin/static/js/45.e8009c00.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/45.e8009c00.chunk.js.LICENSE.txt"
  },
  {
    "revision": "08e3c4658cc490932e1e",
    "url": "/flipacoin-admin/static/js/46.913c0123.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/46.913c0123.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2460182ca07c6201db8e",
    "url": "/flipacoin-admin/static/js/47.4519cc6f.chunk.js"
  },
  {
    "revision": "8f3d60e38346eac4aad4",
    "url": "/flipacoin-admin/static/js/48.3b2bc083.chunk.js"
  },
  {
    "revision": "5ec2cc79827faef5fef5",
    "url": "/flipacoin-admin/static/js/49.1cc6d55e.chunk.js"
  },
  {
    "revision": "f2cc4d6c42d69b3fa167",
    "url": "/flipacoin-admin/static/js/5.5e1220f8.chunk.js"
  },
  {
    "revision": "fdc468f0183e2bfadd40",
    "url": "/flipacoin-admin/static/js/50.aaedfbab.chunk.js"
  },
  {
    "revision": "7b8155aa1f67dfe8c9c6",
    "url": "/flipacoin-admin/static/js/51.1c00a213.chunk.js"
  },
  {
    "revision": "35e4ab247e03b9fd1920",
    "url": "/flipacoin-admin/static/js/52.a63ed429.chunk.js"
  },
  {
    "revision": "3435f7ffdfa2ab09dcbe",
    "url": "/flipacoin-admin/static/js/53.856a3eb8.chunk.js"
  },
  {
    "revision": "f8ae959f3a52f40d6eb3",
    "url": "/flipacoin-admin/static/js/54.4cb73ea9.chunk.js"
  },
  {
    "revision": "489d3d7a5450dd6a7a54",
    "url": "/flipacoin-admin/static/js/55.d31db9a4.chunk.js"
  },
  {
    "revision": "d54c93ae81d5371a312f",
    "url": "/flipacoin-admin/static/js/56.89679825.chunk.js"
  },
  {
    "revision": "0383609a8770d2365b2a",
    "url": "/flipacoin-admin/static/js/57.72b86ca9.chunk.js"
  },
  {
    "revision": "9eee4b7722159060e334",
    "url": "/flipacoin-admin/static/js/58.1053ffa8.chunk.js"
  },
  {
    "revision": "7ccb340373bd2acc6d05",
    "url": "/flipacoin-admin/static/js/59.7a59b6e0.chunk.js"
  },
  {
    "revision": "9eee1b00ef240f84e8f1",
    "url": "/flipacoin-admin/static/js/6.8fec7f11.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/6.8fec7f11.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b1f707370b424a858ff7",
    "url": "/flipacoin-admin/static/js/60.739b63c6.chunk.js"
  },
  {
    "revision": "0547318b4a5b126ae584",
    "url": "/flipacoin-admin/static/js/61.47954446.chunk.js"
  },
  {
    "revision": "cd19377a1cd8a2a27237",
    "url": "/flipacoin-admin/static/js/62.72b44893.chunk.js"
  },
  {
    "revision": "4fb114f7136ec04c1a8d",
    "url": "/flipacoin-admin/static/js/63.247d781c.chunk.js"
  },
  {
    "revision": "0c81c28abe423400c11c",
    "url": "/flipacoin-admin/static/js/7.d167328d.chunk.js"
  },
  {
    "revision": "f7b599e3f88bf94d2af5d3f60873a311",
    "url": "/flipacoin-admin/static/js/7.d167328d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ea76c72a238add1f61b7",
    "url": "/flipacoin-admin/static/js/8.df8619e6.chunk.js"
  },
  {
    "revision": "f44a97fc36c98cf54e2c",
    "url": "/flipacoin-admin/static/js/9.e07c2c6c.chunk.js"
  },
  {
    "revision": "d967ce52107f38c6969f",
    "url": "/flipacoin-admin/static/js/main.9569fe76.chunk.js"
  },
  {
    "revision": "fae8eb133b7c09b968b6",
    "url": "/flipacoin-admin/static/js/runtime-main.cab84f5d.js"
  },
  {
    "revision": "f1c39bddd98308d592280a043ae373e6",
    "url": "/flipacoin-admin/static/media/FAC-LOGO.f1c39bdd.png"
  },
  {
    "revision": "45bc9a197a82b2184132d9302571a1f1",
    "url": "/flipacoin-admin/static/media/admin.45bc9a19.png"
  },
  {
    "revision": "b9c73089fd14dcb97bf597665f575ac1",
    "url": "/flipacoin-admin/static/media/bell.b9c73089.svg"
  },
  {
    "revision": "0668938486df8e4ded8fd7bb86c72452",
    "url": "/flipacoin-admin/static/media/block.06689384.svg"
  },
  {
    "revision": "24886bacc88f3dfbf038a60f4f9f0921",
    "url": "/flipacoin-admin/static/media/bot.24886bac.svg"
  },
  {
    "revision": "ae6d8356288db42a438a49fc4bd53b4e",
    "url": "/flipacoin-admin/static/media/buttons.ae6d8356.svg"
  },
  {
    "revision": "54c5d4c68ff0df625eea98a10b16f6f7",
    "url": "/flipacoin-admin/static/media/cards.54c5d4c6.svg"
  },
  {
    "revision": "977becb6db37f454bad0a5b18f6e647a",
    "url": "/flipacoin-admin/static/media/cart.977becb6.svg"
  },
  {
    "revision": "057753b09a212e5160fe854595ffe79f",
    "url": "/flipacoin-admin/static/media/charts.057753b0.svg"
  },
  {
    "revision": "f7fdff0357cd6bbf4d41ff8aac44a033",
    "url": "/flipacoin-admin/static/media/chat.f7fdff03.svg"
  },
  {
    "revision": "80c792931a140e6917fa643593bca0c5",
    "url": "/flipacoin-admin/static/media/coin.80c79293.svg"
  },
  {
    "revision": "f08813da08c47f23122a2827c74b2fb2",
    "url": "/flipacoin-admin/static/media/coupon.f08813da.svg"
  },
  {
    "revision": "d34c7b50751314310124af5f5b5fbcf3",
    "url": "/flipacoin-admin/static/media/create-account-office-dark.d34c7b50.jpeg"
  },
  {
    "revision": "41b2c6a1c926a8d4f86152f315c7a0bb",
    "url": "/flipacoin-admin/static/media/create-account-office.41b2c6a1.jpeg"
  },
  {
    "revision": "669401e2e4096f9c206e1813f94f2bd0",
    "url": "/flipacoin-admin/static/media/delete.669401e2.svg"
  },
  {
    "revision": "c34040acd2b1249c7cd75ce72a0a36f6",
    "url": "/flipacoin-admin/static/media/dropdown.c34040ac.svg"
  },
  {
    "revision": "c95d727ec5861e3bd1c40034aec6c2ff",
    "url": "/flipacoin-admin/static/media/earning.c95d727e.svg"
  },
  {
    "revision": "41c3abf6450e891dd3dd0c725187eb92",
    "url": "/flipacoin-admin/static/media/edit.41c3abf6.svg"
  },
  {
    "revision": "e8dbb81080cd5c72c595ae891f61fc0b",
    "url": "/flipacoin-admin/static/media/favicon.e8dbb810.png"
  },
  {
    "revision": "df8aaef727cafdb462dc6a3ef66021d6",
    "url": "/flipacoin-admin/static/media/forbidden.df8aaef7.svg"
  },
  {
    "revision": "6db046dc83427f6c5152a760ec3c9d98",
    "url": "/flipacoin-admin/static/media/forgot-password-office-dark.6db046dc.jpeg"
  },
  {
    "revision": "ac5c499bcee89dd25a8b8c80ed46fb8e",
    "url": "/flipacoin-admin/static/media/forgot-password-office.ac5c499b.jpeg"
  },
  {
    "revision": "2da2d1896888bd5229d978ee2298b072",
    "url": "/flipacoin-admin/static/media/forms.2da2d189.svg"
  },
  {
    "revision": "14c57205ad4f4e99cd8b45547800a3e8",
    "url": "/flipacoin-admin/static/media/game.14c57205.svg"
  },
  {
    "revision": "77016819da953ea8a4a60950acb99b99",
    "url": "/flipacoin-admin/static/media/github.77016819.svg"
  },
  {
    "revision": "0d8cfa09614809887b157eba25082af1",
    "url": "/flipacoin-admin/static/media/heart.0d8cfa09.svg"
  },
  {
    "revision": "9bce792512f4e921fa481dcc272660a5",
    "url": "/flipacoin-admin/static/media/home.9bce7925.svg"
  },
  {
    "revision": "5d5cd2055b2ae7f03053b5e243f01620",
    "url": "/flipacoin-admin/static/media/icon.5d5cd205.png"
  },
  {
    "revision": "a824586f0a38494843dc7b98d84ccd47",
    "url": "/flipacoin-admin/static/media/league.a824586f.svg"
  },
  {
    "revision": "cb4a995ff675060363e7489041041b85",
    "url": "/flipacoin-admin/static/media/login-office-dark.cb4a995f.jpeg"
  },
  {
    "revision": "e8edbe5b89f1a31eb88a2ff2d3cb34eb",
    "url": "/flipacoin-admin/static/media/mail.e8edbe5b.svg"
  },
  {
    "revision": "df9ba7c81d8c805ebf3d84a48bd9d57c",
    "url": "/flipacoin-admin/static/media/menu.df9ba7c8.svg"
  },
  {
    "revision": "62a5a8fff7ff6bef7bf961f2a889dc21",
    "url": "/flipacoin-admin/static/media/modals.62a5a8ff.svg"
  },
  {
    "revision": "235b238e2d98c19986f60c19ec2fdb0e",
    "url": "/flipacoin-admin/static/media/money.235b238e.svg"
  },
  {
    "revision": "cdf19a70cc4aad218e3b50d3ee1f6866",
    "url": "/flipacoin-admin/static/media/moon.cdf19a70.svg"
  },
  {
    "revision": "a9704b46814fc81873ac98ca917aa5c4",
    "url": "/flipacoin-admin/static/media/notification.a9704b46.svg"
  },
  {
    "revision": "570b0d66f31d545fdbdc30f5eefaa126",
    "url": "/flipacoin-admin/static/media/outlineCog.570b0d66.svg"
  },
  {
    "revision": "011a8da20be3a5ddd88f392574549839",
    "url": "/flipacoin-admin/static/media/outlineLogout.011a8da2.svg"
  },
  {
    "revision": "50f0ae3e598fe90d94336b5492c772c1",
    "url": "/flipacoin-admin/static/media/outlinePerson.50f0ae3e.svg"
  },
  {
    "revision": "6650d5109fafc0724eac274c3b43eed5",
    "url": "/flipacoin-admin/static/media/pages.6650d510.svg"
  },
  {
    "revision": "c4fada77c844618fef90d2194039d452",
    "url": "/flipacoin-admin/static/media/people.c4fada77.svg"
  },
  {
    "revision": "70205477154d7db80b2f05e9716eb3c1",
    "url": "/flipacoin-admin/static/media/search.70205477.svg"
  },
  {
    "revision": "71c83b534f68121c2e24011e464623cd",
    "url": "/flipacoin-admin/static/media/settings.71c83b53.svg"
  },
  {
    "revision": "e72f14b8a27c721f10d5eb87e8ec3d2f",
    "url": "/flipacoin-admin/static/media/sun.e72f14b8.svg"
  },
  {
    "revision": "b9ce44e708d154ec60a8deabeb3e8e58",
    "url": "/flipacoin-admin/static/media/tables.b9ce44e7.svg"
  },
  {
    "revision": "363c49e4f74fa93affa964689967406a",
    "url": "/flipacoin-admin/static/media/tournament.363c49e4.svg"
  },
  {
    "revision": "f3c7c3b232acfe1a6250f640a0a17741",
    "url": "/flipacoin-admin/static/media/trash.f3c7c3b2.svg"
  },
  {
    "revision": "758d4ea92606195e7b3245047e7f8c4c",
    "url": "/flipacoin-admin/static/media/trophy.758d4ea9.png"
  },
  {
    "revision": "c6bd77d7d4321627a185c1cbc89276d8",
    "url": "/flipacoin-admin/static/media/twitter.c6bd77d7.svg"
  },
  {
    "revision": "50d7bcea8b900a0d51c407df18b726ee",
    "url": "/flipacoin-admin/static/media/user.50d7bcea.svg"
  },
  {
    "revision": "4d17d984fe601c2810b35f1ac207a30c",
    "url": "/flipacoin-admin/static/media/view.4d17d984.svg"
  },
  {
    "revision": "7f5a55ecf21dd1d848585c4db79c8818",
    "url": "/flipacoin-admin/static/media/voucher.7f5a55ec.svg"
  },
  {
    "revision": "1113e51cd421885a70455575e87db7e2",
    "url": "/flipacoin-admin/static/media/word.1113e51c.svg"
  }
]);